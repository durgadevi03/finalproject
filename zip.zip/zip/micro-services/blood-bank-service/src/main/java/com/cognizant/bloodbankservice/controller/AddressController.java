package com.cognizant.bloodbankservice.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.bloodbankservice.service.AddressService;

@RestController
@RequestMapping("/address")
public class AddressController {
	private static final Logger LOGGER = LoggerFactory.getLogger(AddressController.class);

	@Autowired
	AddressService addressService;

	@GetMapping("/state")
	public List<String> getState() {
		return addressService.getState();

	}

	@GetMapping("/area/{state}")
	public List<String> getArea(@PathVariable String state) {
		LOGGER.info("state" + state);
		String substring = state.substring(3);
		LOGGER.info("substring" + substring);
		return addressService.getArea(substring);

	}

	@GetMapping("/pincode/{area}")
	public Integer getPincode(@PathVariable String area) {
		String substring = area.substring(3);
		return addressService.getPincode(substring);

	}

}
