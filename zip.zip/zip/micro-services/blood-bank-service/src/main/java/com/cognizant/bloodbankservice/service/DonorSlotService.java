package com.cognizant.bloodbankservice.service;

import java.sql.Date;
import java.sql.Time;
import java.util.List;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.bloodbankservice.model.Hospital;
import com.cognizant.bloodbankservice.model.SlotBooking;
import com.cognizant.bloodbankservice.repository.DonorSlotRepository;
import com.cognizant.bloodbankservice.repository.HospitalRepository;

@Service
public class DonorSlotService {

	private static final Logger LOGGER = LoggerFactory.getLogger(DonorSlotService.class);

	@Autowired
	DonorSlotRepository donorSlotRepository;

	@Autowired
	HospitalRepository hospitalRepository;

	@Transactional
	public List<String> getHospitalList(int pincode) {
		return hospitalRepository.getHospitalList(pincode);
	}

	@Transactional
	public int getNoOfDonors(String hospitalName, Date date, Time time) {
		int hospitalId = hospitalRepository.findId(hospitalName);
		LOGGER.info("Hospital id" + hospitalId);
		List<SlotBooking> s = donorSlotRepository.findAll();
		int count = 0;
		for (SlotBooking booking : s) {
			LOGGER.info(booking.getDate() + " " + booking.getTime());
			if (booking.getHospital().getName().equals(hospitalName) && booking.getTime().equals(time)
					&& booking.getDate().equals(date)) {
				count++;
			}
		}
		LOGGER.info("count " + count);
		return count;
	}

	@Transactional
	public void saveSlot(SlotBooking slot, String hospitalName) {
		LOGGER.info("hospital name " + hospitalName);
		Hospital hospital = hospitalRepository.findByName(hospitalName);
		slot.setHospital(hospital);
		LOGGER.info("slot " + slot);
		donorSlotRepository.save(slot);
	}

}
