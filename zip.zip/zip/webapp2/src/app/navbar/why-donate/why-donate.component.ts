import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-why-donate',
  templateUrl: './why-donate.component.html',
  styleUrls: ['./why-donate.component.css']
})
export class WhyDonateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
