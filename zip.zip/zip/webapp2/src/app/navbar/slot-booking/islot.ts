import { Time } from '@angular/common';

export interface ISlot {
    date:Date;
	time: Time;
	
}
