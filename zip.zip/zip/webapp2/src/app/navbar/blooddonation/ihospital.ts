export interface IHospital {

    name:string;
	
	state:string; 
	
	area:string;
	
    pincode:number;
}
