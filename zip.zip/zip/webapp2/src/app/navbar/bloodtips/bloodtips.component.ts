import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bloodtips',
  templateUrl: './bloodtips.component.html',
  styleUrls: ['./bloodtips.component.css']
})
export class BloodtipsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
