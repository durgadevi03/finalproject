export interface IBloodRequest {

    bloodGroup:string;
	name:string;
    contactNo:number;
    state:string;
    area:string;
    pincode:string
	
}
