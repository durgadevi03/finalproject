export interface IExpSharing {

    hospitalName: string;
    hospitalArea: string;
    feedBack: string;
}
