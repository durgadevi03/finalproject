export interface IAddress {
    id: number;
    state: string;
    area: string;
    pincode: number;
}
