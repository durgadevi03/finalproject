import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './site/home/home.component';
import { LoginComponent } from './site/login/login.component';
import { RegistrationComponent } from './site/registration/registration.component';
import { AppComponent } from './app.component';
import { AboutusComponent } from './navbar/aboutus/aboutus.component';
import { BloodavailabilityComponent } from './navbar/bloodavailability/bloodavailability.component';
import { BlooddonationComponent } from './navbar/blooddonation/blooddonation.component';
import { BloodtipsComponent } from './navbar/bloodtips/bloodtips.component';

import { RequestbloodComponent } from './navbar/requestblood/requestblood.component';
import { AvailableStatusComponent } from '././navbar/available-status/available-status.component';
import { UserPageComponent } from './site/user-page/user-page.component';
import { SlotBookingComponent } from './navbar/slot-booking/slot-booking.component';
import { ExperienceSharingComponent } from './navbar/experience-sharing/experience-sharing.component';
import { WhyDonateComponent } from './navbar/why-donate/why-donate.component';

const routes: Routes = [
  { path:'home', component : HomeComponent},
  {path:'login', component : LoginComponent},
  {path:'register', component : RegistrationComponent},
  {path:'aboutus', component : AboutusComponent},
  {path:'availability', component : BloodavailabilityComponent},
  {path:'blooddonation', component : BlooddonationComponent},
  {path:'bloodtips', component : BloodtipsComponent},
  {path:'requestblood', component : RequestbloodComponent},
  {path:'availablestatus', component : AvailableStatusComponent},
  {path:'userpage', component : UserPageComponent},
  {path:'bookslot/:pincode', component : SlotBookingComponent},
  {path:'feedBack', component : ExperienceSharingComponent},
  {path:'why', component : WhyDonateComponent},

 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
