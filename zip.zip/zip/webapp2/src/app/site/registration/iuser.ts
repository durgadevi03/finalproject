
export interface IUser {
    username: string;
    firstname: string;
    lastname: string;
    password: string;
    age: number;
    gender: string;
    contactNo:string;
    email: string;
    weight: number;
    bloodgroup: string;
   state:string;
   pincode:number;
   area:string


}
